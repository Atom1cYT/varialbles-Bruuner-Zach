﻿using System;

namespace varialbles_Bruuner_Zach
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Declares an interger to store a favorite number
            int favoritenumber;
            // Booleans initialized to fasle for jumping and running
            bool isjumping = false, isrunning = false;
            // Declared random float variable
              float myfloat;
            // assigning the favoritenumber to 3
            favoritenumber = 3;
            // assigning myfloat to 54.65
            myfloat = 54.65f;
            // initalizing constant finalgrade to 90
            const double finalgrade = 90.0;

            // Prints all variables to console
            Console.WriteLine("favorite #:" + favoritenumber);
            Console.WriteLine("Jumping:" + isjumping);
            Console.WriteLine("Running:" + isrunning);
            Console.WriteLine("Random floating#:" + myfloat);
            Console.WriteLine("Final grade:" + finalgrade);
                 

        } 
    }
        
           




}            